# Install Prisma CLI as a development dependency
npm install prisma --save-dev

# Install Prisma Client and PostgreSQL driver dependencies
npm install @prisma/client @prisma/adapter-pg pg



# Initialize Prisma and configure client output directory
npx prisma init



npm cache clean --force



npm i helmet compression cookie-parser
npm i -D @types/compression @types/cookie-parser

npm i class-validator class-transformer




npm install @nestjs/swagger
npm install bcrypt
npm install @types/bcrypt --save-dev
npm install @nestjs/jwt
npm install @nestjs/passport passport passport-jwt
npm install @types/passport-jwt --save-dev


npm install -D tsx




What should you build first in NestJS?
This is the development order I recommend.
Recommended development roadmap
Build in this order

1. Phase 1 — Project setup
   
   NestJS, PostgreSQL, Prisma, environment configuration, validation, exception handling and Swagger.
2. Phase 2 — Company & Authentication
   
   Company, Branch, User, login, registration, JWT access/refresh tokens, RolesGuard and permissions.
3. Phase 3 — Master Management
   
   Customer, Vendor, Driver, Vehicle and their documents.
4. Phase 4 — Routes & Pricing
   
   Route, RateCard and quotation calculation.
5. Phase 5 — Booking Management
   
   Quotation, Booking, BookingItem, BookingStatusHistory and LorryReceipt.
6. Phase 6 — Trip & Dispatch
   
   Trip, TripBooking, vehicle assignment, driver assignment and trip status management.
7. Phase 7 — Delivery Management
   
   EwayBill, ProofOfDelivery and delivery confirmation.
8. Phase 8 — Vehicle Operations
   
   FuelEntry, VehicleMaintenance, Tyre and GPS tracking.
9. Phase 9 — Finance & Accounts
   
   Invoice, InvoiceItem, Payment, VendorPayment, DriverTransaction, OfficeExpense and LedgerEntry.
10. Phase 10 — Notifications & Reporting
    
    Notification, AuditLog, dashboards, reports and analytics.













NestJS folder structure


transportation-management/
│
├── prisma/
│   ├── schema.prisma
│   ├── migrations/
│   └── seed.ts
│
├── src/
│   ├── main.ts
│   ├── app.module.ts
│   │
│   ├── config/
│   │   └── configuration.ts
│   │
│   ├── database/
│   │   ├── prisma.module.ts
│   │   └── prisma.service.ts
│   │
│   ├── common/
│   │   ├── decorators/
│   │   ├── guards/
│   │   ├── filters/
│   │   ├── interceptors/
│   │   ├── pipes/
│   │   ├── enums/
│   │   └── utils/
│   │
│   ├── modules/
│   │   ├── auth/
│   │   ├── company/
│   │   ├── branches/
│   │   ├── users/
│   │   ├── customers/
│   │   ├── vendors/
│   │   ├── drivers/
│   │   ├── vehicles/
│   │   ├── routes/
│   │   ├── rate-cards/
│   │   ├── quotations/
│   │   ├── bookings/
│   │   ├── lorry-receipts/
│   │   ├── trips/
│   │   ├── dispatch/
│   │   ├── eway-bills/
│   │   ├── proof-of-delivery/
│   │   ├── maintenance/
│   │   ├── fuel/
│   │   ├── gps/
│   │   ├── invoices/
│   │   ├── payments/
│   │   ├── expenses/
│   │   ├── ledger/
│   │   ├── notifications/
│   │   └── audit-logs/
│   │
│   └── generated/
│       └── prisma/
│
├── test/
├── .env
├── .env.example
├── package.json
└── tsconfig.json














nest g module modules/auth

nest g controller modules/auth

nest g service modules/auth




nest g module modules/company

nest g controller modules/company

nest g service modules/company




Build this first workflow:
Initial application workflow
1. Create Company
   
   Admin registers a transportation company.
2. Create Super Admin
   
   The first administrator is created for that company.
3. Login
   
   Validate email/phone and password.
4. Generate JWT
   
   Return access token and refresh token.
5. Create Branch
   
   Admin creates company branches.
6. Create Employees
   
   Admin creates MANAGER, DISPATCHER and ACCOUNTANT users.
7. Role-based access
   
   Protect APIs according to user permissions.

Your first APIs should be:
Method	Endpoint	Purpose
POST	/api/v1/company/register	Register company
POST	/api/v1/auth/login	Login
POST	/api/v1/auth/refresh	Refresh access token
POST	/api/v1/auth/logout	Logout
GET	/api/v1/auth/profile	Logged-in user
POST	/api/v1/branches	Create branch
GET	/api/v1/branches	List branches
POST	/api/v1/users	Create employee
GET	/api/v1/users	List employees




















1. Recommended development order
Priority	Module	Functionality
1	Auth	Login, register, JWT, refresh token
2	Company	Company management
3	Branch	Branch CRUD
4	Users	Employee/user management
5	Customers	Customer CRUD
6	Vendors	Vendor CRUD
7	Vehicles	Vehicle and document management
8	Drivers	Driver and driver documents
9	Routes & Rates	Route and pricing management
10	Quotations	Quotation management
11	Bookings	Booking and LR management
12	Trips	Trip and dispatch management
13	Expenses	Trip and office expenses
14	Invoices	Billing and payments
15	GPS	Vehicle tracking
16	Reports	Analytics and reports